#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdio_ext.h>
#include <stdlib.h>

#define MAXBUF 1024

int repeat_receiver = 1;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
    char data[MAXBUF];
} t_data;

typedef struct {
    int number;
    int snd_queue;
    int rcv_queue;
} tide;

void* sender(void* msg);
void* receiver(void* msg);

int main (int argc, char *argv[]){
    tide num;
    pthread_t snd_thread, rcv_thread;
    void *thread_result;



    if(argc!=3){
        printf("Usage: %s <snd_key> <rcv_key>",argv[0]);
        exit(1);
         //Usage: ./hw3_example <snd_key> <rcv_key>
    }
    printf("snd_key = %d, rcv_key = %d\n",atoi(argv[1]),atoi(argv[2]));
    num.snd_queue = msgget(atoi(argv[1]), IPC_CREAT | 0660);
    num.rcv_queue = msgget(atoi(argv[2]), IPC_CREAT | 0660);
    if(num.snd_queue == -1 || num.rcv_queue == -1){
        perror("msgget error");
        return -1;
    }
    pthread_create(&snd_thread,NULL,sender,&num);
    pthread_create(&rcv_thread,NULL,receiver,&num);
    pthread_join(rcv_thread,&thread_result);
    pthread_join(snd_thread,&thread_result);
    msgctl(num.snd_queue, IPC_RMID, NULL);
    msgctl(num.rcv_queue, IPC_RMID, NULL);
    //deallocate
}

void* sender(void* arg){
    tide* num;
    num = (tide*) arg;
    pthread_t tid;
    char buf[MAXBUF];
    t_data datas;
    while(1){
       printf("[mesg] ");
        fgets(buf, MAXBUF, stdin);
        buf[strlen(buf)-1] = '\0';
        if(strcmp(buf,"quit")==0) {
            repeat_receiver = 0;
            break;
        }
        strcpy(datas.data,buf);
       // pthread_mutex_lock(&mutex);
        if ( -1 == msgsnd((*num).snd_queue,&datas, sizeof(datas) - sizeof(long), 0))
        {
            perror( "msgsnd() 실패");
            exit(1);
        }
       // pthread_mutex_unlock(&mutex);
    }
}

void* receiver(void* arg){
    struct winsize w;
    ioctl(0, TIOCGWINSZ, &w);
    int terminal_columns = w.ws_col;
    int terminal_rows = w.ws_row;
    tide* num;
    num = (tide*) arg;
    char buf[MAXBUF];
    int i;
    t_data datas;
    __fpurge(stdin);
    while(repeat_receiver == 1){
      if ( -1 == msgrcv((*num).rcv_queue, &datas, sizeof(datas)- sizeof(long), 0, IPC_NOWAIT))
      {
       continue;
      }
        for(int i = 0;i<terminal_columns/2-7;i++)
            printf(" ");
      printf("[incoming] ");
      printf( "%s\n", datas.data);
      fflush(stdout);
      printf("[mesg] ");
      fflush(stdout);
      usleep(1000);
    }
}

