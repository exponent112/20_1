// If the comments are hard to read because of the color,
// type ':set background=dark'

/***

    This program reads texts and switches the case of the characters (lower case <-> upper case) until the user types "quit".

    Example)
        Input a text: Welcome!
        convered text = wELCOME!
        Input a text: God bless you!
        convered text = gOD BLESS YOU!
        Input a text: quit
        Bye!

    It launches a child process and communicates with it through two ordinary pipes, one to send the original text and the other to receive the converted text.

    Complete the program using ORDINARY PIPES by following the instructions.
    DO NOT use other IPC such as shared memory or message queue.

    The main creates two pipes and a child process.
    
    Then, the parent process repeats the followings until the user types "quit".
        Read a text line from the user.
        Send the text to the child through pipe.
        Receive and display the converted text.

    The child process repeats the followings until it receives "quit" from the parent.
        Read a text line from the parent through one pipe.
        Convert all upper case characters to the corresponding lower case characters and vice versa.
        Write the converted text to the parent through the other pipe.

    Hint) To read a text line from the user, use the following code.
            printf("Input a text: ");
            fgets(src, BUFFER_SIZE - 1, stdin);
            int len = strlen(src) - 1;
            src[len] = 0;                // trim '\n'

    Note! Before the parent terminates, there the child processing MUST terminate.
        You can check whether the child is still running by check currently running processes by 'ps -al'.

***/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

#define TRUE 1
#define FALSE 0

#define READ_END 0
#define WRITE_END 1

#define BUFFER_SIZE 256

void SwitchCase(int in[], int out[]);

int main()
{
    int in[2];        // pipe from parent to child
    int out[2];        // pipe from child to parent
    pid_t pid;

    
    if(pipe(in) == -1){
        fprintf(stderr, "Pipe failed");
        return 1;
    }
    if(pipe(out) == -1){
        fprintf(stderr, "Pipe failed");
        return 1;
    }
    //    TO DO: Create two ordinary pipes

    //  TO DO: Create child process
    pid = fork();

    // On parent process,
    if(pid<0){
        //error
        fprintf(stderr,"Fork failed");
        return 1;
    }
    if(pid>0){
        //parent process
        close(in[READ_END]);
        close(out[WRITE_END]);
        //close the unused end of the pipe
        while(1){ // Repeats the followings until the user types "quit".
            int n_str =0;
            char src[BUFFER_SIZE]; //c
            char c_read_msg[BUFFER_SIZE]; //p
            printf("Input a text: ");
            fgets(src, BUFFER_SIZE - 1, stdin);
            // Read a text line from the user.
            int len = strlen(src) - 1;
            src[len] = 0;                // trim '\n'
            write(in[WRITE_END], src, strlen(src)+1);
            if(strcmp(src,"quit")==0) {
                break;
            }
            else{
                // Send the text to the child through pipe.
                n_str = read(out[READ_END],c_read_msg,BUFFER_SIZE);
                // Receive and display the converted text.
                printf("convered text = %s\n", c_read_msg);
            }
        }
        wait(NULL); // Wait for the child to terminate
        close(in[WRITE_END]);
        close(out[READ_END]);
        printf("Bye!\n"); // Print a good-bye message
    }
    else{
         SwitchCase(in,out);
        //child process
        // On child process call SwitchCase(in, out);
    }
    return 0;
}

void SwitchCase(int in[], int out[])
{
    close(in[WRITE_END]);
    close(out[READ_END]);
           while(1){
                // Repeats the followings until it receives "quit" from the parent.
               char buffer[BUFFER_SIZE]; //c
               read(in[READ_END],buffer,BUFFER_SIZE);
               //    Receive a text line from the parent through pipe in.
               if(strcmp(buffer,"quit")==0) {
                   break;
               }
               else{
                   for(int i = 0;i<strlen(buffer);i++){
                       if(isalpha(buffer[i])==0) {
                           buffer[i] = buffer[i];
                           continue;
                       }
                       else if(isupper(buffer[i])==0){
                           buffer[i] = toupper(buffer[i]);
                       }
                       else{
                           buffer[i] = tolower(buffer[i]);
                       }
                   }
                   write(out[WRITE_END], buffer, strlen(buffer)+1);
               }
           }
           close(in[READ_END]);
           close(out[WRITE_END]);
}

